import java.lang.*;

public class Demo
{
	public static void main(String []args)
	{
		//UpdateEmp l=new UpdateEmp();
		//l.setVisible(true);
	}
}